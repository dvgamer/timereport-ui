import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'

const _f756b3ee = () => interopDefault(import('..\\pages\\app\\index.vue' /* webpackChunkName: "pages_app_index" */))
const _05bd15da = () => interopDefault(import('..\\pages\\audit.vue' /* webpackChunkName: "pages_audit" */))
const _1f74d875 = () => interopDefault(import('..\\pages\\sign-in\\index.vue' /* webpackChunkName: "pages_sign-in_index" */))
const _516a4fd4 = () => interopDefault(import('..\\pages\\app\\file-fccr.vue' /* webpackChunkName: "pages_app_file-fccr" */))
const _3c65c505 = () => interopDefault(import('..\\pages\\app\\inbound-ftp.vue' /* webpackChunkName: "pages_app_inbound-ftp" */))
const _4a1637be = () => interopDefault(import('..\\pages\\app\\kafka-feed.vue' /* webpackChunkName: "pages_app_kafka-feed" */))
const _0aff4711 = () => interopDefault(import('..\\pages\\app\\ssis-staging.vue' /* webpackChunkName: "pages_app_ssis-staging" */))
const _93309d3e = () => interopDefault(import('..\\pages\\inspect\\snippet\\index.vue' /* webpackChunkName: "pages_inspect_snippet_index" */))
const _6053fdc8 = () => interopDefault(import('..\\pages\\inspect\\terminal.vue' /* webpackChunkName: "pages_inspect_terminal" */))
const _8c3ceec4 = () => interopDefault(import('..\\pages\\setting\\configuration.vue' /* webpackChunkName: "pages_setting_configuration" */))
const _88fb0efa = () => interopDefault(import('..\\pages\\setting\\database.vue' /* webpackChunkName: "pages_setting_database" */))
const _7576cfee = () => interopDefault(import('..\\pages\\inspect\\snippet\\_id.vue' /* webpackChunkName: "pages_inspect_snippet__id" */))
const _7cfca2ec = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))
const _2d06b47c = () => interopDefault(import('..\\pages\\_\\coding\\_type\\_id.vue' /* webpackChunkName: "pages___coding__type__id" */))

Vue.use(Router)

if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected and scrollToTop is not explicitly disabled
  if (
    to.matched.length < 2 &&
    to.matched.every(r => r.components.default.options.scrollToTop !== false)
  ) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some(r => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise((resolve) => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}

export function createRouter() {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,

    routes: [{
      path: "/app",
      component: _f756b3ee,
      name: "app"
    }, {
      path: "/audit",
      component: _05bd15da,
      name: "audit"
    }, {
      path: "/sign-in",
      component: _1f74d875,
      name: "sign-in"
    }, {
      path: "/app/file-fccr",
      component: _516a4fd4,
      name: "app-file-fccr"
    }, {
      path: "/app/inbound-ftp",
      component: _3c65c505,
      name: "app-inbound-ftp"
    }, {
      path: "/app/kafka-feed",
      component: _4a1637be,
      name: "app-kafka-feed"
    }, {
      path: "/app/ssis-staging",
      component: _0aff4711,
      name: "app-ssis-staging"
    }, {
      path: "/inspect/snippet",
      component: _93309d3e,
      name: "inspect-snippet"
    }, {
      path: "/inspect/terminal",
      component: _6053fdc8,
      name: "inspect-terminal"
    }, {
      path: "/setting/configuration",
      component: _8c3ceec4,
      name: "setting-configuration"
    }, {
      path: "/setting/database",
      component: _88fb0efa,
      name: "setting-database"
    }, {
      path: "/inspect/snippet/:id",
      component: _7576cfee,
      name: "inspect-snippet-id"
    }, {
      path: "/",
      component: _7cfca2ec,
      name: "index"
    }, {
      path: "/*/coding/:type?/:id?",
      component: _2d06b47c,
      name: "all-coding-type-id"
    }],

    fallback: false
  })
}
